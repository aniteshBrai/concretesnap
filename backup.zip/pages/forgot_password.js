import React from 'react';
import ForgotPassword from '../components/forgot_password'

const forgot_password = () => {
  return <ForgotPassword/>;
};

export default forgot_password;
