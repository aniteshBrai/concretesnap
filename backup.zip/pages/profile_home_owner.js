import React from 'react';
import ProfileHomeOwner from '../components/profile_home_owner'

const profile_home_owner = () => {
  return <ProfileHomeOwner/>;
};

export default profile_home_owner;
