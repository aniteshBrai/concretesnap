import React from 'react';
import ChangePassword from '../components/change_password'

const change_password = () => {
  return <ChangePassword/>;
};

export default change_password;
