import React from 'react';
import ProfileControctor from '../components/profile_contractor'

const profile_contractor = () => {
  return <ProfileControctor/>;
};

export default profile_contractor;
