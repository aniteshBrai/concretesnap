import React from 'react';
import Home from '../components/home'

const home = () => {
  return <Home/>;
};

export default home;
