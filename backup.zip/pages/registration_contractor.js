import React from 'react';
import RegistrationContractor from '../components/registration_contractor'

const registration = () => {
  return <RegistrationContractor/>;
};

export default registration;
