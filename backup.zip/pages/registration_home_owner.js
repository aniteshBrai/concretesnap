import React from 'react';
import RegistrationHomeOwner from '../components/registration_home_owner'

const registration_home_owner = () => {
  return <RegistrationHomeOwner/>;
};

export default registration_home_owner;
