import React from 'react';

const index = () => {
  return <div>Registration Contractor</div>;
};

export default index;
