import React from 'react';

const index = () => {
  return <div>Forgot Password</div>;
};

export default index;
