import React from 'react';

const index = () => {
  return <div>Profile Home Owner</div>;
};

export default index;
