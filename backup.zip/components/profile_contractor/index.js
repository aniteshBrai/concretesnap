import React from 'react';

const index = () => {
  return <div>Profile Controctor</div>;
};

export default index;
