import React from 'react';

const index = () => {
  return <div>Change Password</div>;
};

export default index;
