import React from 'react';

const index = () => {
  return <div>Login Component</div>;
};

export default index;
