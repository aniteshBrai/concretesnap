import React from 'react';

const index = () => {
  return <div>Registration Home Owner</div>;
};

export default index;
